/*------------------------------------------PARTE IV--------------------------------------------------------------------------------------------------------------*/
------------------------------------------------- Ejer 1 ---------------------------------------------------------------------------------------------------------  
CREATE OR REPLACE VIEW V_LISTADO_OT AS
WITH 
	ORD_T AS
		(SELECT T_OR.NUM_COCHE, T_OR.COD_OT, T_OR.TIPO, T_OR.FEC_INI_REL, T_OR.FEC_FIN_REL
		FROM T_ORDEN_TRABAJO T_OR
		),
	CANT_COST_REP AS
		(SELECT S_MR.COD_OT, S_M.COD_MOVIMIENTO, SUM(S_M.CANTIDAD) Cant_Rep_Util, SUM(S_M.CANTIDAD * S_M.COSTO_UNIT) Costo_Rep_Util 
		from S_MOVIM_DET S_M
		LEFT JOIN S_MOVIM_REP S_MR ON S_M.COD_MOVIMIENTO = S_MR.COD_MOVIMIENTO
		group by S_MR.COD_OT, S_M.COD_MOVIMIENTO
		),
	TOT_HS AS
		(SELECT T_OT.COD_OT, SUM(T_OT.HS_INVERTIDAS) TOT_HS, SUM(T_OT.HS_INVERTIDAS) * (SELECT PAGO_MECXHORA FROM G_PARAMETROS) Costo_Mano_Obra
		FROM T_OT_DETALLE T_OT
		LEFT JOIN S_MOVIM_REP S_MR ON T_OT.COD_OT = S_MR.COD_OT
		GROUP BY T_OT.COD_OT
		)
SELECT L_C.NUM_COCHE,
	CASE LENGTH(L_C.CHAPA) 
	WHEN 6 THEN SUBSTR(L_C.CHAPA,1,3) ||'-'|| SUBSTR(L_C.CHAPA,3,6)
	WHEN 7 THEN SUBSTR(L_C.CHAPA,1,4) ||'-'|| SUBSTR(L_C.CHAPA,4,7)
	END CHAPA, T_OR.COD_OT, T_OR.TIPO, T_OR.FEC_INI_REL, T_OR.FEC_FIN_REL, CCR.Cant_Rep_Util, CCR.Costo_Rep_Util, HS.TOT_HS Tot_hs_Inv,
	HS.Costo_Mano_Obra, (HS.Costo_Mano_Obra + CCR.Costo_Rep_Util) Costo_Total
FROM L_COCHE L_C 
LEFT JOIN ORD_T T_OR ON L_C.NUM_COCHE = T_OR.NUM_COCHE
left join TOT_HS HS ON T_OR.COD_OT = HS.COD_OT
LEFT JOIN CANT_COST_REP CCR ON HS.COD_OT = CCR.COD_OT
where T_OR.FEC_INI_REL between '01/01/19' AND '30/06/19';
/*//*---------------Parte iv---------------------*/
------------------------------
SQL> alter session set "_ORACLE_SCRIPT"=true; 
SQL> SPOOL PARTE4.SQL CREATE
SQL> SELECT 'CREATE USER T_'||SUBSTR(PRIMER_NOMBRE,1,1)||PRIMER_APELL||' IDENTIFIED BY T_'||SUBSTR(PRIMER_NOMBRE,1,1)||PRIMER_APELL||'
  2  DEFAULT TABLESPACE BASEDATOS2TP
  3  PASSWORD EXPIRE;' FROM G_EMPLEADO WHERE TIPO_EMPLEADO = 'T';SQL> SPOOL OFF

'CREATEUSERT_'||SUBSTR(PRIMER_NOMBRE,1,1)||PRIMER_APELL||'IDENTIFIEDBYT_'||SUBST
--------------------------------------------------------------------------------
CREATE USER T_sdfdfsdfsd IDENTIFIED BY T_sdfdfsdfsd
DEFAULT TABLESPACE BASEDATOS2TP
PASSWORD EXPIRE;


SQL> SPOOL OFF
SQL> @ PARTE4.SQL
SP2-0734: inicio "SQL> SELEC..." de comando desconocido - resto de la lÝnea ignorado.
SP2-0734: inicio "'CREATEUSE..." de comando desconocido - resto de la lÝnea ignorado.

Usuario creado.

SP2-0734: inicio "SQL> spool..." de comando desconocido - resto de la lÝnea ignorado.

SQL> SPOOL PARTE4_2.SQL CREATE
SQL> SELECT 'GRANT SELECT ANY TABLE, INSERT ANY TABLE, DELETE ANY TABLE TO '||USERNAME||';' FROM DBA_USERS JOIN DBA_TABLES ON DBA_USERS.DEFAULT_TABLESPACE = DBA_TABLES.TABLESPACE_NAME and
  2  DBA_USERS.DEFAULT_TABLESPACE = 'BASEDATOS2TP' and USERNAME <> 'BD2TP'
  3  GROUP BY USERNAME;

'GRANTSELECTANYTABLE,INSERTANYTABLE,DELETEANYTABLETO'||USERNAME||';'
--------------------------------------------------------------------------------
GRANT SELECT ANY TABLE, INSERT ANY TABLE, DELETE ANY TABLE TO T_SDFDFSDFSD;

SQL> SPOOL OFF
SQL> @ PARTE4_2.SQL
SP2-0734: inicio "SQL> SELEC..." de comando desconocido - resto de la lÝnea ignorado.
SP2-0734: inicio "'GRANTSELE..." de comando desconocido - resto de la lÝnea ignorado.

Concesi¾n terminada correctamente.

SP2-0734: inicio "SQL> SPOOL..." de comando desconocido - resto de la lÝnea ignorado. 
SQL> SPOOL PARTE4_2.SQL REPLACE
SQL> SELECT 'GRANT CREATE SESSION TO '||USERNAME||';' FROM DBA_USERS JOIN DBA_TABLES ON DBA_USERS.DEFAULT_TABLESPACE = DBA_TABLES.TABLESPACE_NAME and
  2  DBA_USERS.DEFAULT_TABLESPACE = 'BASEDATOS2TP' and USERNAME <> 'PEPITO'
  3  GROUP BY USERNAME;

'GRANTCREATESESSIONTO'||USERNAME||';'
--------------------------------------------------------------------------------
GRANT CREATE SESSION TO T_SDFDFSDFSD;

SQL> SPOOL OFF
SQL> @ PARTE4_2.SQL
SP2-0734: inicio "SQL> SELEC..." de comando desconocido - resto de la lÝnea ignorado.
SP2-0734: inicio "'GRANTCREA..." de comando desconocido - resto de la lÝnea ignorado.

Concesi¾n terminada correctamente.

SP2-0734: inicio "SQL> SPOOL..." de comando desconocido - resto de la lÝnea ignorado.
Este si es el completo

