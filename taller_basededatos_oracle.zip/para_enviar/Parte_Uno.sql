/* ------------------------------------------Creacion Usuario y Tablespace-------------------------------------------------------- */
CREATE TABLESPACE BASED2TP
LOGGING
DATAFILE 'C:\oracle\oradata\based2tp.dbf'
SIZE 45M REUSE
AUTOEXTEND ON NEXT 22500 K MAXSIZE 135M;
---Se adjunta el excel de esta parte en la carpeta de TP

alter session set "_ORACLE_SCRIPT"=true;

create user BD2TP identified by BD2TP	
       DEFAULT TABLESPACE BASEDATOS2TP
       TEMPORARY TABLESPACE TEMP;
	   
GRANT DBA TO BD2TP WITH ADMIN OPTION;

--FALTA ASIGNAR ESPACIO A LAS TABLAS

/* ------------------------------------------Creacion Esquema--------------------------------------------------------------------- */
--------------------------Creacion Tablas-----------------------------------------------------------------
create table F_TIMBRADO
(
	/* P * */ NRO_TIMBRADO NUMBER(12) NOT NULL,
	/* * */ FEC_AUTORIZACION DATE NOT NULL,
	/* * */ VALIDO_HASTA DATE NOT NULL,
	/* * */ ESTABLECIMIENTO NUMBER(3) NOT NULL,
	/* * */ EMISION NUMBER(3) NOT NULL,
	/* * */ NRO_DESDE NUMBER(7) NOT NULL,
	/* * */ NRO_HASTA NUMBER(7) NOT NULL,
	/* * */ ULT_NUM_UTILIZADA NUMBER NOT NULL,
	/* F * */ NUM_COCHE NUMBER(8) NOT NULL
)
;

create table F_BOLETOSXLOTE
(
	/* P * */ ID_LOTE NUMBER(12) NOT NULL,
	/* F * */ NRO_TIMBRADO NUMBER(12) NOT NULL,
	/* * */ FEC_ENTREGA DATE NOT NULL,
	/* * */ NUM_BOLETO_D NUMBER(7) NOT NULL,
	/* * */ NUM_BOLETO_H NUMBER(7) NOT NULL
)
;

create table F_REDONDO
(
	/* P * */ ID_REDONDO NUMBER(15) NOT NULL,
	/* * */ FECHA DATE NOT NULL,
	/* * */ HORA_SALIDA VARCHAR2(5) NOT NULL,
	HORA_LLEGADA VARCHAR2(5),
	/* F * */ COD_CHOFER NUMBER(8) NOT NULL,
	/* F * */ NUM_COCHE NUMBER(8) NOT NULL,
	/* * */ CANT_BOL_VEND NUMBER(7) NOT NULL,
	COMPLETADO VARCHAR2(1),
	/* F */ ID_MOTIVO NUMBER(5),
	/* F * */ COD_TRAMO NUMBER(5) NOT NULL,
	/* F * */ ID_LOTE NUMBER(12) NOT NULL
)
;

create table G_EMPLEADO 
(
	/* P * */ COD_EMPL NUMBER(8) NOT NULL,
	/* * */ CI VARCHAR2(15) NOT NULL,
	RUC VARCHAR2(20),
	/* * */ PRIMER_NOMBRE VARCHAR2(15) NOT NULL,
	SEG_NOMBRE VARCHAR2(15),
	/* * */ PRIMER_APELL VARCHAR2(15) NOT NULL,
	SEG_APELL VARCHAR2(15),
	/* * */ SEXO VARCHAR2(1) NOT NULL,
	/* * */ FEC_NACIMIENTO DATE NOT NULL,
	/* * */ FEC_INGRESO DATE NOT NULL,
	FECHA_SALIDA DATE,
	/* * */ TIPO_EMPLEADO VARCHAR2(1) NOT NULL,
	NRO_REG_CONDUCIR VARCHAR2(20)
)
;

create table G_MOTIVO 
(
	/* P * */ ID_MOTIVO NUMBER(5) GENERATED ALWAYS AS IDENTITY START WITH 1 INCREMENT BY 1 MINVALUE 1,
	/* * */ DESCRIPCION VARCHAR2(40) NOT NULL,
	/* * */ ESTADO VARCHAR2(1) NOT NULL
)
;

create table G_PARAMETROS
(
	/* * */ COSTO_PASAJ_CON NUMBER(6) NOT NULL,
	/* * */ COSTO_PASAJ_DIF NUMBER(6) NOT NULL,
	/* * */ CANT_RED_DIA NUMBER(4) NOT NULL,
	/* * */ PAGO_X_REDONDO NUMBER(8) NOT NULL,
	/* * */ PAGO_MECXHORA NUMBER(8) NOT NULL
)
;
 
create table G_BARRIO
(
	/* P * */ COD_BARRIO NUMBER(5) GENERATED ALWAYS AS IDENTITY START WITH 1 INCREMENT BY 1 MINVALUE 1,
	/* * */ NOMBRE VARCHAR2(40) NOT NULL,
	/* * */ CANT_HABITANTES NUMBER(8) NOT NULL
)
;

create table G_TRAMO
(
	/* P * */ COD_TRAMO NUMBER(5) NOT NULL,
	/* * */ NOMBRE VARCHAR2(40) NOT NULL
)
;
 
create table G_TRAMOXBARRIO 
(
	/* PF* */ COD_TRAMO NUMBER(5) NOT NULL,
	/* PF* */ COD_BARRIO NUMBER(5) NOT NULL
)
;

create table L_COCHE 
(
	/* P * */ NUM_COCHE NUMBER(8) NOT NULL,
	/* * */ CHAPA VARCHAR2(12) NOT NULL,
	/* * */ NRO_CHASIS VARCHAR2(30) NOT NULL,
	/* * */ FEC_ADQUISICION DATE NOT NULL,
	/* * */ PRECIO_COMPRA NUMBER(15) NOT NULL,
	/* * */ KILOMETRAJE NUMBER(8) NOT NULL,
	/* * */ ULT_MANTENIMIENTO DATE NOT NULL,
	/* * */ TIENE_SEGURO VARCHAR2(1) NOT NULL,
	/* * */ ESTADO VARCHAR2(1) NOT NULL,
	/* * */ FOTO BLOB NOT NULL,
	/* F * */ ID_MODELO NUMBER(6) NOT NULL,
	/* F * */ ID_MARCA NUMBER(5) NOT NULL
)
;

create table L_MARCA 
(
	/* P * */ ID_MARCA NUMBER(5) GENERATED ALWAYS AS IDENTITY START WITH 1 INCREMENT BY 1 MINVALUE 1,
	/* * */ DESCRIPCION VARCHAR2(50) NOT NULL
)
;

create table L_MODELO 
(
	/* P * */ ID_MODELO NUMBER(6) NOT NULL,
	/* PF* */ ID_MARCA NUMBER(5) NOT NULL,
	/* * */ DESCRIPCION VARCHAR2(60) NOT NULL,
	/* * */ ANHO_FABRICACION NUMBER(4) NOT NULL,
	/* * */ CANT_PASA_SENT NUMBER(3) NOT NULL,
	/* * */ CANT_PASA_PAR NUMBER(3) NOT NULL,
	/* * */ ES_CONVENCIONAL VARCHAR2(1) NOT NULL
)
;

create table T_ACTIVIDAD
(
	/* P * */ COD_ACTIV NUMBER(5) GENERATED ALWAYS AS IDENTITY START WITH 1 INCREMENT BY 1 MINVALUE 1,--AGREGAR MINVALUE
	/* * */ DESCRIPCION VARCHAR2(500) NOT NULL,
	/* * */ HS_MIN_ASIGNADAS NUMBER(4,1) NOT NULL
)
;

create table T_REPUESTO
(
	/* P * */ ID_REPUESTO NUMBER(8) NOT NULL,
	/* * */ NOMBRE_LARGO VARCHAR2(100) NOT NULL,
	NOMBRE_ABREV VARCHAR2(30),
	/* * */ UM VARCHAR2(5) NOT NULL,
	/* * */ ULT_COSTO_COMP NUMBER(10) NOT NULL
)
;

create table T_DEPOSITO
(
	/* P * */ ID_DEPOSITO NUMBER(5) NOT NULL,
	/* * */ DESCRIPCION VARCHAR2(50) NOT NULL
)
;

create table S_REPXDEP 
(
	/* PF* */ ID_REPUESTO NUMBER(8) NOT NULL,
	/* PF* */ ID_DEPOSITO NUMBER(5) NOT NULL,
	/* * */ CANT_ACT_STOCK NUMBER(8) NOT NULL,
	/* * */ CANT_STK_MIN NUMBER(8) NOT NULL
)
;

create table T_ORDEN_TRABAJO
(
	/* P * */ COD_OT NUMBER(10) NOT NULL,
	/* * */ FEC_INI_PRE DATE NOT NULL,
	/* * */ FEC_FIN_PRE DATE NOT NULL,
	FEC_INI_REL DATE,
	FEC_FIN_REL DATE,
	/* * */ TIPO VARCHAR2(1) NOT NULL,
	/* * */ ESTADO VARCHAR2(1) NOT NULL,
	/* F * */ NUM_COCHE NUMBER(8) NOT NULL,
	OBSERVACION VARCHAR2(500)
)
;

create table T_OT_DETALLE
(
	/* PF* */ COD_OT NUMBER(10) NOT NULL,
	/* P * */ NRO_ITEM NUMBER(5) NOT NULL,
	/* F * */ COD_ACTIV NUMBER(5) NOT NULL,
	/* * */ HS_INVERTIDAS NUMBER(4,1) NOT NULL,
	/* F * */ COD_MECANICO NUMBER(8) NOT NULL
)
;

create table S_MOVIM_REP
(
	/* P * */ COD_MOVIMIENTO NUMBER(10) NOT NULL,
	/* * */ FEC_OPERACION DATE NOT NULL,
	/* * */ USUARIO_CARGA VARCHAR2(128) NOT NULL,
	/* F */ COD_OT NUMBER(10),
	/* F */ NRO_ITEM NUMBER(5)
)
;

create table S_MOVIM_DET
(
	/* PF* */ COD_MOVIMIENTO NUMBER(10) NOT NULL,
	/* P * */ NRO_ITEM NUMBER(5) NOT NULL,
	/* * */ TIPO_MOVIM VARCHAR2(1) NOT NULL,
	/* * */ CANTIDAD NUMBER(8) NOT NULL,
	/* * */ COSTO_UNIT NUMBER(10) NOT NULL,
	/* F * */ ID_REPUESTO NUMBER(8) NOT NULL,
	/* F * */ ID_DEPOSITO NUMBER(5) NOT NULL
)
;
---------------------------------------------PKs Simples-------------------------------------------------------------------------------------
alter table F_TIMBRADO
  add constraint PKTIMBRADO primary key (NRO_TIMBRADO);

alter table F_BOLETOSXLOTE
  add constraint PKBOLETOSXLOTE primary key (ID_LOTE);

alter table F_REDONDO
  add constraint PKREDONDO primary key (ID_REDONDO);

alter table G_EMPLEADO
  add constraint PKEMPLEADO primary key (COD_EMPL);

alter table G_MOTIVO
  add constraint PKMOTIVO primary key (ID_MOTIVO);

alter table G_BARRIO
  add constraint PKBARRIO primary key (COD_BARRIO);

alter table G_TRAMO
  add constraint PKTRAMO primary key (COD_TRAMO);

alter table L_COCHE
  add constraint PKCOCHE primary key (NUM_COCHE);

alter table L_MARCA
  add constraint PKMARCA primary key (ID_MARCA);

alter table T_ACTIVIDAD
  add constraint PKACTIVIDAD primary key (COD_ACTIV);

alter table T_REPUESTO
  add constraint PKREPUESTO primary key (ID_REPUESTO);

alter table T_DEPOSITO
  add constraint PKDEPOSITO primary key (ID_DEPOSITO);

alter table T_ORDEN_TRABAJO
  add constraint PKORDEN_TRABAJO primary key (COD_OT);

alter table S_MOVIM_REP
  add constraint PKMOVIM_REP primary key (COD_MOVIMIENTO);
--------------------------------------------------------FKs Simples----------------------------------------------------------------
alter table F_TIMBRADO
  add constraint FKTIMBRADO foreign key (NUM_COCHE)
  references L_COCHE (NUM_COCHE);

alter table F_BOLETOSXLOTE
  add constraint FKBOLETOSXLOTE foreign key (NRO_TIMBRADO)
  references F_TIMBRADO (NRO_TIMBRADO);

alter table F_REDONDO
  add constraint FKREDONDO foreign key (COD_CHOFER)
  references G_EMPLEADO (COD_EMPL);

alter table F_REDONDO
  add constraint FKREDONDO2 foreign key (NUM_COCHE)
  references L_COCHE (NUM_COCHE);

alter table F_REDONDO
  add constraint FKREDONDO3 foreign key (ID_MOTIVO)
  references G_MOTIVO (ID_MOTIVO);

alter table F_REDONDO
  add constraint FKREDONDO4 foreign key (COD_TRAMO)
  references G_TRAMO (COD_TRAMO);

alter table F_REDONDO
  add constraint FKREDONDO5 foreign key (ID_LOTE)
  references F_BOLETOSXLOTE (ID_LOTE);

alter table G_TRAMOXBARRIO
  add constraint FKTRAMOXBARRIO foreign key (COD_TRAMO)
  references G_TRAMO (COD_TRAMO);

alter table G_TRAMOXBARRIO
  add constraint FKTRAMOXBARRIO2 foreign key (COD_BARRIO)
  references G_BARRIO (COD_BARRIO);

alter table L_MODELO
  add constraint FKMODELO foreign key (ID_MARCA)
  references L_MARCA (ID_MARCA);

alter table S_REPXDEP
  add constraint FKREPXDEP foreign key (ID_REPUESTO)
  references T_REPUESTO (ID_REPUESTO);

alter table S_REPXDEP
  add constraint FKREPXDEP2 foreign key (ID_DEPOSITO)
  references T_DEPOSITO (ID_DEPOSITO);

alter table T_ORDEN_TRABAJO
  add constraint FKORDEN_TRABAJO foreign key (NUM_COCHE)
  references L_COCHE (NUM_COCHE);

alter table T_OT_DETALLE
  add constraint FKOT_DETALLE foreign key (COD_OT)
  references T_ORDEN_TRABAJO (COD_OT);

alter table T_OT_DETALLE
  add constraint FKOT_DETALLE2 foreign key (COD_ACTIV)
  references T_ACTIVIDAD (COD_ACTIV);

alter table T_OT_DETALLE
  add constraint FKOT_DETALLE3 foreign key (COD_MECANICO)
  references G_EMPLEADO (COD_EMPL);

alter table S_MOVIM_DET
  add constraint FKMOVIM_DET foreign key (COD_MOVIMIENTO)
  references S_MOVIM_REP (COD_MOVIMIENTO);
---------------------------------------------------FKs y PKs Compuestas--------------------------------------------------------------------
alter table G_TRAMOXBARRIO
  add constraint PKTRAMOXBARRIO primary key (COD_TRAMO, COD_BARRIO);

alter table L_MODELO
  add constraint PKMODELO primary key (ID_MODELO, ID_MARCA);

alter table L_COCHE
  add constraint FKCOCHE foreign key (ID_MODELO, ID_MARCA)
  references L_MODELO (ID_MODELO, ID_MARCA);

alter table S_REPXDEP
  add constraint PKREPXDEP primary key (ID_REPUESTO, ID_DEPOSITO);

alter table T_OT_DETALLE
  add constraint PKOT_DETALLE primary key (COD_OT, NRO_ITEM);

alter table S_MOVIM_REP
  add constraint FKMOVIM_REP foreign key (COD_OT, NRO_ITEM)
  references T_OT_DETALLE (COD_OT, NRO_ITEM);

alter table S_MOVIM_DET
  add constraint PMOVIM_DET primary key (COD_MOVIMIENTO, NRO_ITEM);

alter table S_MOVIM_DET
  add constraint FKMOVIM_DET2 foreign key (ID_REPUESTO, ID_DEPOSITO)
  references S_REPXDEP (ID_REPUESTO, ID_DEPOSITO);
----------------------------------------Restricciones------------------------------------------------------------------------------------
---Punto a
--CHK1
alter table F_TIMBRADO 
  add constraint CHKTIMBRADO CHECK (MONTHS_BETWEEN(VALIDO_HASTA, FEC_AUTORIZACION) = 12);
--CHK2
alter table F_TIMBRADO 
  add constraint CHKTIMBRADO2 CHECK (NRO_HASTA > NRO_DESDE);

---Punto b
alter table S_MOVIM_DET  
  add constraint CHKMOVIM_DET CHECK (TIPO_MOVIM = 'E' OR TIPO_MOVIM = 'S');
---Punto c
--CHK1 and default
alter table T_ORDEN_TRABAJO modify (ESTADO default 'P');
alter table T_ORDEN_TRABAJO  
  add constraint CHKORDEN_TRABAJO CHECK (ESTADO = 'P' OR ESTADO = 'C' OR 
  (ESTADO = 'E' AND FEC_INI_REL IS NOT NULL) OR ESTADO = 'X' OR (ESTADO = 'T' AND FEC_FIN_REL IS NOT NULL));

---Punto d  
alter table F_BOLETOSXLOTE modify (FEC_ENTREGA default SYSDATE);

---Punto e
alter table F_REDONDO  
  add constraint CHKREDONDO CHECK ((COMPLETADO = 'N' AND ID_MOTIVO IS NOT NULL) OR COMPLETADO = 'S');
alter table F_REDONDO  
  add constraint CHKREDONDO2 CHECK (SUBSTR(HORA_SALIDA,3,1) = ':' AND SUBSTR(HORA_LLEGADA,3,1) = ':');

---Punto f
ALTER TABLE L_COCHE
	ADD CONSTRAINT UQCOCHE UNIQUE (CHAPA);
alter table L_COCHE  
  add constraint CHKCOCHE CHECK 
  (((EXTRACT(YEAR FROM FEC_ADQUISICION) = 2019) AND (EXTRACT(MONTH FROM FEC_ADQUISICION) >= 7) AND (LENGTH(CHAPA) = 7))
	OR ((EXTRACT(YEAR FROM FEC_ADQUISICION) > 2019) AND (LENGTH(CHAPA) = 7))
	OR ((EXTRACT(YEAR FROM FEC_ADQUISICION) = 2019) AND (EXTRACT(MONTH FROM FEC_ADQUISICION) < 7) AND (LENGTH(CHAPA) = 6))
	OR ((EXTRACT(YEAR FROM FEC_ADQUISICION) < 2019) AND (LENGTH(CHAPA) = 6))
  );

